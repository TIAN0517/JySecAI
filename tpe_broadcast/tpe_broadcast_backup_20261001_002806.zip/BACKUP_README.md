# Taipei Broadcast Local Backup

This archive is a private operational backup created on 20261001_002806 Asia/Taipei.
It contains live environment/configuration files, bot routing credentials,
login state, the current dedup snapshot, source, tests, reports, GUI files,
and the JY logo. Keep the ZIP private and do not upload it to a public service.

Restore the `JySecAI` tree with its directory layout intact because the GUI
loads `../jysecai-logo.png`. Review absolute paths in the systemd unit before
installing it under `~/.config/systemd/user/`. Install the recorded Python
dependencies, then run both unittest files. Stop legacy Taipei broadcasters
before enabling `tpe-broadcast-multibot.service` to avoid duplicate messages.

The restored service uses `--skip-existing-on-start`; omit the saved state only
when a fresh dedup baseline is intended. Never restore a stale lock file.
