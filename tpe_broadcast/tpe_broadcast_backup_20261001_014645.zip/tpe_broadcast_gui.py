#!/usr/bin/env python3
"""
TPE 119 Broadcast — Desktop GUI Control Panel

Features:
  - Real-time bot health monitoring (green/red indicators)
  - Multi-city support (Taipei, Taoyuan, Kaohsiung, extensible)
  - Multi-group routing: OHCA alerts and regular dispatches to separate channels
  - Auto-bind Telegram group ID via getUpdates
  - Start/stop daemon from control panel
  - Only pushes NEW cases (dedup state persisted in /tmp/broadcast_pushed_cases.json)
  - Checkbox-based config: which city, OHCA path, dispatch path, auto-start

Usage:
  python3 tpe_broadcast_gui.py

Design:
  - tkinter (stdlib, no pip install needed — resource-efficient)
  - Polls daemon HTTP status server at 127.0.0.1:58888/status every 3s
  - Communicates with daemon via subprocess + CLI args
"""

import os, sys, json, time, subprocess, threading, signal
import urllib.request, urllib.error
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from gui_branding import apply_window_icon

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DAEMON_SCRIPT = os.path.join(BASE_DIR, "broadcast_daemon.py")
TOKEN_FILE = os.path.join(BASE_DIR, "tpe119_token.json")
STATE_FILE = "/tmp/broadcast_pushed_cases.json"
BASE_STATUS_PORT = 58888

# ── All Taiwan cities from getAllCity API ──
# City codes map to Taiwan Fire Dept county codes (used by IPS dispatch)
CITIES = {
    "01": {"city": "台北市", "en": "Taipei"},
    "05": {"city": "桃園市", "en": "Taoyuan"},
    "11": {"city": "高雄市", "en": "Kaohsiung"},
}

class BroadcastGUI:
    def __init__(self, root):
        self.root = root
        apply_window_icon(self.root)
        self.root.title("TPE 119 Broadcast — 控制面板")
        self.root.geometry("900x650")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.daemon_proc = None
        self.poll_running = False
        self.poll_thread = None

        self._build_ui()

    # ── UI layout ──────────────────────────────────────────
    def _build_ui(self):
        # ── Top: Title + daemon status ──
        top = tk.Frame(self.root, bg="#2b2b2b", height=50)
        top.pack(fill="x")
        title = tk.Label(top, text="TPE 119 緊急案件廣播控制面板",
                         font=("Arial", 14, "bold"), fg="white", bg="#2b2b2b")
        title.pack(pady=5)

        # ── Main container: left config, right monitoring ──
        main = tk.Frame(self.root)
        main.pack(fill="both", expand=True, padx=10, pady=10)

        # Left column: Configuration
        left = tk.LabelFrame(main, text="設定", font=("Arial", 10, "bold"))
        left.pack(side="left", fill="y", padx=(0, 10), anchor="n")

        # City selection checkboxes
        tk.Label(left, text="監控縣市:").pack(anchor="w", pady=(10, 2))
        self.city_vars = {}
        for code, info in CITIES.items():
            var = tk.BooleanVar(value=(code == "01"))
            cb = tk.Checkbutton(left, text=f"{info['city']} ({code})",
                                variable=var, command=self._on_city_change)
            cb.pack(anchor="w", padx=15)
            self.city_vars[code] = var

        # Bot token entry
        tk.Label(left, text="Telegram Bot Token:").pack(anchor="w", pady=(15, 2))
        self.token_entry = tk.Entry(left, width=40, font=("Courier", 9))
        self.token_entry.pack(pady=2)
        self.token_entry.insert(0, "8944573992:")

        # Group ID entries
        tk.Label(left, text="一般派遣群組 ID:").pack(anchor="w", pady=(10, 2))
        self.dispatch_group_entry = tk.Entry(left, width=40, font=("Courier", 9))
        self.dispatch_group_entry.pack(pady=2)
        self.dispatch_group_entry.insert(0, "-1004487319117")

        tk.Label(left, text="OHCA 警示群組 ID:").pack(anchor="w", pady=(10, 2))
        self.ohca_group_entry = tk.Entry(left, width=40, font=("Courier", 9))
        self.ohca_group_entry.pack(pady=2)
        self.ohca_group_entry.insert(0, "")

        # Auto-bind button
        btn_frame = tk.Frame(left)
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="自動綁定群組 ID",
                  command=self.auto_bind_group, width=15).pack(side="left", padx=5)

        # Checkbox: only push new cases
        self.new_only_var = tk.BooleanVar(value=True)
        tk.Checkbutton(left, text="僅推播新案件 (去重)",
                       variable=self.new_only_var, state="disabled").pack(anchor="w", pady=5)

        # Checkbox: OHCA alert
        self.ohca_var = tk.BooleanVar(value=True)
        tk.Checkbutton(left, text="啟用 OHCA 雙車警示",
                       variable=self.ohca_var).pack(anchor="w", pady=5)

        # Checkbox: auto-start daemon
        self.autostart_var = tk.BooleanVar(value=False)
        tk.Checkbutton(left, text="啟動時自動啟動daemon",
                       variable=self.autostart_var).pack(anchor="w", pady=5)

        # ── Right column: Monitoring ──
        right = tk.LabelFrame(main, text="監控", font=("Arial", 10, "bold"))
        right.pack(side="right", fill="both", expand=True, padx=(10, 0))

        # Daemon control buttons
        ctrl_top = tk.Frame(right)
        ctrl_top.pack(fill="x", pady=5)
        self.start_btn = tk.Button(ctrl_top, text="啟動 Daemon",
                                   command=self.start_daemon,
                                   bg="#4CAF50", fg="white", font=("Arial", 9, "bold"))
        self.start_btn.pack(side="left", padx=5, fill="x", expand=True)
        self.stop_btn = tk.Button(ctrl_top, text="停止 Daemon",
                                  command=self.stop_daemon,
                                  bg="#f44336", fg="white", font=("Arial", 9, "bold"))
        self.stop_btn.pack(side="left", padx=5, fill="x", expand=True)

        # Daemon status label
        self.daemon_status_label = tk.Label(ctrl_top, text="狀態: 未啟動",
                                            font=("Arial", 9), fg="gray")
        self.daemon_status_label.pack(pady=5)

        # Bot health table
        tk.Label(right, text="Bot 健康度", font=("Arial", 10, "bold")).pack(anchor="w")
        self.health_frame = tk.Frame(right)
        self.health_frame.pack(fill="x", pady=5)
        self.health_indicators = {}  # city_code -> (label, status_label)
        for code, info in CITIES.items():
            row = tk.Frame(self.health_frame)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=info["city"], width=10, anchor="w").pack(side="left")
            dot = tk.Label(row, text="●", font=("Arial", 14), fg="gray")
            dot.pack(side="left", padx=5)
            status = tk.Label(row, text="未檢查", font=("Arial", 9), fg="gray")
            status.pack(side="left")
            self.health_indicators[code] = (dot, status)

        # Stats display
        tk.Label(right, text="推播統計", font=("Arial", 10, "bold")).pack(anchor="w", pady=(15, 0))
        self.stats_text = tk.Text(right, height=8, font=("Courier", 9), wrap="word")
        self.stats_text.pack(fill="both", expand=True, pady=5)
        self.stats_text.config(state="disabled")

        # Log display
        tk.Label(right, text="操作日誌", font=("Arial", 10, "bold")).pack(anchor="w")
        self.log_text = scrolledtext.ScrolledText(right, height=10, font=("Courier", 8),
                                                   wrap="word", bg="#1e1e1e", fg="#d4d4d4")
        self.log_text.pack(fill="both", expand=True, pady=5)
        self.log_text.config(state="disabled")

    def _on_city_change(self):
        # Called when city checkboxes toggled; daemon must restart to apply
        selected = [c for c, v in self.city_vars.items() if v.get()]
        self._log(f"選定縣市: {', '.join(CITIES[c]['city'] for c in selected) if selected else '無'}")

    def _log(self, msg):
        now = time.strftime("%H:%M:%S")
        self.log_text.config(state="normal")
        self.log_text.insert("end", f"[{now}] {msg}\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")

    def _update_stats(self, status_data=None):
        stats = status_data or {}
        lines = [
            f"已推播案件: {(len(stats.get('pushed_cases')) if isinstance(stats.get('pushed_cases'), (list, set, dict)) else stats.get('pushed_cases', 0))}",
            f"OHCA 地址數: {len(stats.get('ohca_addresses', 0)) if isinstance(stats.get('ohca_addresses'), int) else len(stats.get('ohca_addresses', []))}",
            f"最近現場: {stats.get('recent_scenes', 0)}",
            f"IPS 快取: {stats.get('ips_cache_time', 0)}",
            f"dispatch 快取: {stats.get('dispatch_cache_time', 0)}",
        ]
        # Try to get local dedup state for accurate counts
        try:
            with open(STATE_FILE, 'r') as f:
                state = json.load(f)
            lines[0] = f"已推播案件: {len(state.get('cases', []))}"
            lines[1] = f"OHCA 地址數: {len(state.get('ohca_keys', []))}"
        except (FileNotFoundError, json.JSONDecodeError, ValueError):
            pass
        self.stats_text.config(state="normal")
        self.stats_text.delete(1.0, "end")
        self.stats_text.insert("1.0", "\n".join(lines))
        self.stats_text.config(state="disabled")

    def auto_bind_group(self):
        """Use Telegram getUpdates API to auto-discover group ID."""
        token = ''.join(c for c in self.token_entry.get().split(',')[0] if c not in '\r\n\t ').strip()
        if not token or len(token) < 30:
            messagebox.showwarning("警告", "請先填入完整的 Telegram Bot Token")
            return
        self._log("正在自動綁定群組 ID...")

        def _do_bind():
            try:
                url = f"https://api.telegram.org/bot{token}/getUpdates"
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                if not data.get("ok"):
                    self._log(f"getUpdates 失敗: {data.get('description', '未知錯誤')}")
                    return
                bound = None
                for update in data.get("result", []):
                    chat = update.get("my_chat_member", {}).get("chat", {})
                    if chat.get("type") in ("group", "supergroup"):
                        bound = str(chat.get("id"))
                        break
                    chat = update.get("message", {}).get("chat", {})
                    if chat.get("type") in ("group", "supergroup"):
                        bound = str(chat.get("id"))
                        break
                if bound:
                    self.dispatch_group_entry.delete(0, "end")
                    self.dispatch_group_entry.insert(0, bound)
                    self._log(f"自動綁定群組 ID: {bound}")
                else:
                    self._log("找不到群組 — 請先將 bot 加入群組並發送訊息")
            except Exception as e:
                self._log(f"自動綁定錯誤: {e}")

        threading.Thread(target=_do_bind, daemon=True).start()

    # ── Daemon management ──────────────────────────────────
    def start_daemon(self):
        """Start broadcast_daemon.py with current GUI config."""
        token = ''.join(c for c in self.token_entry.get().split(',')[0] if c not in '\r\n\t ').strip()
        if not token or len(token) < 30:
            messagebox.showwarning("警告", "請填入 Telegram Bot Token")
            return

        selected = self._selected_cities()
        if not selected:
            messagebox.showwarning("警示", "請至少選選一個縣市")
            return

        dispatch_group = self.dispatch_group_entry.get().strip()
        ohca_group = self.ohca_group_entry.get().strip()

        # Multi-city mode: use --all-cities with status port offset
        use_all_cities = len(selected) > 1
        cmd = [
            sys.executable, "-u", DAEMON_SCRIPT,
            "--interval", "10",
        ]
        if use_all_cities:
            cmd.append("--all-cities")
        else:
            cmd += ["--city", selected[0]]

        if token:
            cmd += ["--tg-bot-token", token]
        if dispatch_group:
            cmd += ["--dispatch-group-id", dispatch_group]
        if ohca_group:
            cmd += ["--ohca-group-id", ohca_group]
        if use_all_cities:
            cmd += ["--status-port", str(BASE_STATUS_PORT)]

        self._log(f"啟動 daemon: {' '.join(cmd)}")

        try:
            self.daemon_proc = subprocess.Popen(
                cmd,
                cwd=BASE_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env={**os.environ,
                     "HTTP_PROXY": "socks5://202.160.76.166:11086",
                     "HTTPS_PROXY": "socks5://202.160.76.166:11086",
                     "http_proxy": "socks5://202.160.76.166:11086",
                     "https_proxy": "socks5://202.160.76.166:11086"}
            )
            self._log(f"Daemon PID: {self.daemon_proc.pid}")
            self.daemon_status_label.config(text="狀態: 運行中", fg="green")
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
            self._start_polling()
        except Exception as e:
            self._log(f"啟動失敗: {e}")
            messagebox.showerror("錯誤", f"無法啟動 daemon:\n{e}")

    def stop_daemon(self):
        """Stop the running daemon via SIGTERM (graceful, saves dedup state)."""
        if not self.daemon_proc or self.daemon_proc.poll() is not None:
            self._log("Daemon 未在運行")
            return
        self._log("停止 daemon...")
        try:
            self.daemon_proc.send_signal(signal.SIGTERM)
            try:
                self.daemon_proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.daemon_proc.kill()
                self._log("Daemon 已強制結束")
        except Exception as e:
            self._log(f"停止錯誤: {e}")

        self.daemon_status_label.config(text="狀態: 已停止", fg="red")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")
        self._stop_polling()

    def _selected_city(self):
        """Return the first selected city code (for single-city startup)."""
        for code, var in sorted(self.city_vars.items()):
            if var.get():
                return code
        return None

    def _selected_cities(self):
        """Return list of all selected city codes."""
        return [code for code, var in self.city_vars.items() if var.get()]

    def _mark_city_offline(self, code):
        """Mark a city as offline (daemon not reachable)."""
        if code in self.health_indicators:
            dot, lbl = self.health_indicators[code]
            dot.config(fg="gray")
            lbl.config(text="離線", fg="gray")

    def _start_polling(self):
        self.poll_running = True
        self.poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.poll_thread.start()

    def _stop_polling(self):
        self.poll_running = False

    def _poll_loop(self):
        """Poll daemon status HTTP server for health + stats per city."""
        while self.poll_running:
            selected_cities = self._selected_cities()
            if not selected_cities:
                time.sleep(3)
                continue
            for i, code in enumerate(sorted(selected_cities)):
                port = BASE_STATUS_PORT + i
                status_url = f"http://127.0.0.1:{port}/status"
                try:
                    req = urllib.request.Request(status_url)
                    with urllib.request.urlopen(req, timeout=5) as resp:
                        status = json.loads(resp.read().decode("utf-8"))
                    self.root.after(0, lambda s=status, c=code: self._update_from_status(s, c))
                    self.root.after(0, lambda s=status, c=code: self._update_health(s, c))
                    self.root.after(0, lambda s=status: self._update_stats(s))
                except (urllib.error.URLError, ConnectionRefusedError):
                    self.root.after(0, lambda c=code: self._mark_city_offline(c))
                except Exception:
                    pass
            time.sleep(3)

    def _update_from_status(self, status, code=None):
        running = status.get("running", False)
        if self.daemon_proc and self.daemon_proc.poll() is not None:
            running = False
        label_text = "狀態: 運行中" if running else "狀態: 已停止"
        label_fg = "green" if running else "red"
        self.daemon_status_label.config(text=label_text, fg=label_fg)
        self.start_btn.config(state="normal" if not running else "disabled")
        self.stop_btn.config(state="normal" if running else "disabled")

    def _update_health(self, status, code=None):
        bots = status.get("bot_health", {})
        for code, (dot, lbl) in self.health_indicators.items():
            info = bots.get(code, {})
            if info and info.get("ok"):
                dot.config(fg="green")
                lbl.config(text="正常", fg="green")
            elif info and not info.get("ok"):
                dot.config(fg="red")
                lbl.config(text=info.get("error", "錯誤"), fg="red")
            else:
                dot.config(fg="orange")
                lbl.config(text="檢查中...", fg="orange")

    def on_closing(self):
        if self.daemon_proc and self.daemon_proc.poll() is None:
            if messagebox.askyesno("確認", "Daemon 仍在運行，確定要關閉嗎？"):
                self.stop_daemon()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = BroadcastGUI(root)
    root.mainloop()
