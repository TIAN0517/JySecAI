#!/usr/bin/env python3
"""
TOCP Broadcast Daemon

Auto-pulls up:
  1. Starts login.py --daemon (auto-renews TPE 119 JWT every 2.5h)
  2. Monitors it — auto-restarts on disconnect/crash
  3. Polls citizenCase/search API -> TWD coords -> WGS84 -> reverse-geocode -> push
  4. Only pushes addresses with 號 (building number) — fuzzy skipped
  5. Deduplicates cases by case ID, never re-pushes

Usage:
  python3 broadcast_daemon.py                          # daemon mode (poll TPE 119 API)
  python3 broadcast_daemon.py --coords 25.038779,121.512820  # one-shot push
  python3 broadcast_daemon.py --interval 60             # poll every 60s
  python3 broadcast_daemon.py --city 01                 # Taipei 119 (default)
"""
import os, sys, json, time, subprocess, signal, threading, argparse
import urllib.request, urllib.parse
import requests

# ── Config ──────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOGIN_SCRIPT = os.path.join(BASE_DIR, "login.py")
TOKEN_FILE = os.path.join(BASE_DIR, "tpe119_token.json")

# SOCKS5 proxy for TPE 119 API requests
PROXY = "socks5://202.160.76.166:11086"
PROXIES = {"http": PROXY, "https": PROXY}

# ── IPS (Taiwan Fire Dept dispatch) — authenticated, real-time unit dispatch ──
IPS_COOKIE_FILE = os.path.join(
    os.environ.get("HERMES_CACHE_DIR", os.path.join(os.environ.get("HOME", "/tmp"), ".hermes/cache/scratch")),
    "ips_dispatch_cache.json"
)
IPS_CACHE_TTL = 30  # reuse parsed dispatch data within 30s to avoid re-login
LOCK_FILE = "/tmp/broadcast_daemon.lock"

# ── Dispatch caseList endpoint — unauthenticated, real-time emergency cases ──
DISPATCH_CASELIST_URL = "https://service119.119.gov.taipei/service119/citizenCase/caseList"
_dispatch_cache = {}
_dispatch_cache_time = 0
DISPATCH_CACHE_TTL = 30  # cache dispatch cases for 30s

# Env vars for subprocess (login.py --daemon) — passed explicitly in start_login_daemon

# Import telegram config from tocp_tpe_broadcast.py (avoids duplicating tokens)
sys.path.insert(0, BASE_DIR)
from tocp_tpe_broadcast import TELEGRAM_BOTS, GROUP_ID

# Traffic routing: OHCA alerts can go to a separate group from regular dispatches
GROUP_ID_OHCA = None  # Override with --ohca-group-id
GROUP_ID_DISPATCH = None  # Override with --dispatch-group-id for regular dispatches

# ── Reverse-geocoding ───────────────────────────────────────────
try:
    from geocoding import reverse_geocode, forward_geocode
    HAS_GEOCODING = True
except ImportError:
    HAS_GEOCODING = False

# ── TWD97 → WGS84 coordinate conversion ─────────────────────────
try:
    from pyproj import Transformer
    _twd = Transformer.from_crs("epsg:3826", "epsg:4326", always_xy=True)

    def twd_to_wgs84(cs_x, cs_y):
        """Convert TWD97 (EPSG:3826) coordinates to WGS84 (lat, lng)."""
        lng, lat = _twd.transform(cs_x, cs_y)
        return lat, lng
    HAS_TWD = True

    # Reverse transform: WGS84 → TWD97 (for dispatch address geocoding)
    _wgs_to_twd = Transformer.from_crs("epsg:4326", "epsg:3826", always_xy=True)

    def wgs_to_twd97(lat, lng):
        """Convert WGS84 (lat, lng) to TWD97 (cs_x, cs_y)."""
        cs_x, cs_y = _wgs_to_twd.transform(lng, lat)
        return cs_x, cs_y
except ImportError:
    HAS_TWD = False

# ── Case tracking ────────────────────────────────────────────────
_pushed_cases = set()  # track pushed case IDs to avoid duplicates
_pushed_cases_file = "/tmp/broadcast_pushed_cases.json"  # persisted dedup (survives restart)
# Addresses that already triggered OHCA — prevents cross-cycle repeat at same address
_ohca_addr_keys = set()
_address_counts = {}   # track address → count for OHCA detection
# Cross-cycle OHCA tracking: addr_key → (timestamp, case_data)
_recent_scenes = {}
SCENE_WINDOW_SECONDS = 90  # consider OHCA if same address within 90s

# ── Auto-renew daemon for login.py ──────────────────────────────
_login_process = None
_login_lock = threading.Lock()
_running = True


def load_pushed_cases():
    """Load persisted _pushed_cases and _ohca_addr_keys from file (survives restart)."""
    global _pushed_cases, _ohca_addr_keys
    try:
        with open(_pushed_cases_file, 'r') as f:
            state = json.load(f)
        _pushed_cases = set(state.get("cases", []))
        _ohca_addr_keys = set(state.get("ohca_keys", []))
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        pass  # fresh start


def save_pushed_cases():
    """Persist _pushed_cases and _ohca_addr_keys so restart doesn't re-push everything."""
    try:
        with open(_pushed_cases_file, 'w') as f:
            json.dump({"cases": sorted(_pushed_cases),
                       "ohca_keys": sorted(_ohca_addr_keys)}, f)
    except Exception:
        pass  # non-fatal


def start_login_daemon():
    """Start login.py --daemon as a subprocess for auto token renewal."""
    global _login_process
    with _login_lock:
        if _login_process and _login_process.poll() is None:
            return  # already running
        _login_process = subprocess.Popen(
            [sys.executable, LOGIN_SCRIPT, "--daemon"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=BASE_DIR,
            env={**os.environ, "HTTP_PROXY": PROXY, "HTTPS_PROXY": PROXY,
                 "http_proxy": PROXY, "https_proxy": PROXY}
        )
        print(f"[+] login.py --daemon started (pid={_login_process.pid})", flush=True)


def monitor_login_daemon():
    """Monitor login.py subprocess, restart on crash."""
    global _login_process, _running
    while _running:
        if _login_process:
            rc = _login_process.poll()
            if rc is not None:
                print(f"[!] login.py exited (rc={rc}) — restarting in 5s...", flush=True)
                time.sleep(5)
                start_login_daemon()
        time.sleep(5)


def get_valid_token():
    """Get current TPE 119 token from file, auto-renew via login.py if expired.
    Returns (token, jsessionid) tuple.
    """
    if os.path.exists(TOKEN_FILE):
        try:
            data = json.load(open(TOKEN_FILE))
            token = data.get("token", "")
            exp = data.get("exp", 0)
            if token and time.time() < exp - 9000:  # 2.5h safety margin
                return token, data.get("jsessionid", "")
        except Exception:
            pass
    # Token expired or missing — trigger login.py --check
    subprocess.run([sys.executable, LOGIN_SCRIPT, "--check"],
                   cwd=BASE_DIR, timeout=120,
                   env={**os.environ, "HTTP_PROXY": PROXY, "HTTPS_PROXY": PROXY,
                        "http_proxy": PROXY, "https_proxy": PROXY})
    if os.path.exists(TOKEN_FILE):
        data = json.load(open(TOKEN_FILE))
        return data.get("token", ""), data.get("jsessionid", "")
    return None, None


def fetch_tpe119_cases(city_code="01"):
    """Fetch real-time cases from TPE 119 citizenCase/search API.

    Uses login.py's fetch_cases() which handles token + JSESSIONID.
    Returns list of case dicts or empty list.
    """
    if city_code != "01":
        return []
    sys.path.insert(0, BASE_DIR)
    from login import AutoLoginService119
    bot = AutoLoginService119()
    cases = bot.fetch_cases()
    if cases is None:
        return []
    return cases


def push_to_telegram(city_code, address, coords, case_data=None, target_group=None):
    """Push a single case to Telegram group.
    Pushes whatever the page shows — address, coords, case type, etc.
    Only called for addresses with 號 (building number).
    """
    token = TELEGRAM_BOTS[city_code]["token"]
    chat_id = target_group or GROUP_ID_DISPATCH or GROUP_ID

    # Build message from real case data if available
    if case_data:
        in_time = case_data.get("inTime", "")
        cs_kind = case_data.get("csKindName", "")
        cs_code = case_data.get("csCodeName", "")
        status = case_data.get("caseStatus", "")
        people = case_data.get("peopleCount", "")
        cars = case_data.get("dispCarList", "")
    else:
        in_time = ""
        cs_kind = ""
        cs_code = ""
        status = ""
        people = ""
        cars = ""

    msg = (
        f"🚨 <b>緊急案件 / Case Dispatch</b>\n\n"
        f"🏙️ <b>縣市:</b> {TELEGRAM_BOTS[city_code]['city']}\n"
        f"📍 <b>地址:</b> {address}\n"
        f"🪪 <b>類別:</b> {cs_kind} / {cs_code}\n"
        f"🚑 <b>出勤:</b> {status}\n"
        f"👥 <b>人數:</b> {people}\n"
        f"🚒 <b>車輛:</b> {cars}\n"
        f"⏰ <b>時間:</b> {in_time}\n"
        f"🌐 <b>座標:</b> {coords[0]:.6f}, {coords[1]:.6f}\n"
    )

    payload = {
        "chat_id": chat_id, "text": msg, "parse_mode": "HTML"
    }
    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            timeout=10,
            data=payload
        )
        r = resp.json()
        mid = r.get("result", {}).get("message_id", "?")
        print(f"  [PUSH] {address} → msg_id={mid}", flush=True)
        return True
    except Exception as e:
        print(f"  [ERR]  Telegram push failed: {e}", flush=True)
        return False


def _case_addr_key(case):
    """Generate a normalized address key for grouping OHCA cases.

    Uses TWD97 coordinates when available; falls back to address-string
    hash for cases without geocoding (e.g. IPS dispatch without forward-geocode).
    """
    x = case.get("csX", 0)
    y = case.get("csY", 0)
    if x and y:
        return f"{round(x, 0)}:{round(y, 0)}"
    # Fallback: deterministic hash of address string (same addr → same key)
    addr = case.get("csPlace", "")
    return f"addr_{abs(hash(addr)) % 1000000}"


def push_ohca_alert(city_code, case_list, num_amb=0, target_group=None):
    """Push an OHCA suspicion alert when 2+ ambulances dispatched to same address.
    Routes to GROUP_ID_OHCA if set, otherwise falls back to GROUP_ID.
    """
    if not case_list:
        return
    case = case_list[0]
    cs_x = float(case.get("csX", 0) or 0)
    cs_y = float(case.get("csY", 0) or 0)

    # Address: use csPlace directly if no coordinates (forward-geocode fallback)
    addr = case.get("csPlace", "")
    lat, lng = 0.0, 0.0
    if not cs_x or not cs_y:
        # No coordinates available — use csPlace as-is for display
        pass
    else:
        if HAS_TWD:
            lat, lng = twd_to_wgs84(cs_x, cs_y)
        else:
            print(f"  [FAIL] pyproj not available", flush=True)
            return
        # Try reverse-geocode for a cleaner address; keep csPlace as fallback
        if HAS_GEOCODING:
            geo = reverse_geocode(lat, lng)
            r_addr = geo.get("formatted_address", "")
            if r_addr and "號" in r_addr:
                addr = r_addr

    token = TELEGRAM_BOTS[city_code]["token"]
    car_list = [c.get("dispCarList", "") for c in case_list]
    times = [c.get("inTime", "") for c in case_list]
    amb_count = num_amb if num_amb >= 2 else len(case_list)
    has_ips = any("ips_case_no" in c for c in case_list)
    src = "IPS" if has_ips else "119"
    coord_str = f"{lat:.6f}, {lng:.6f}" if (lat and lng) else "未知 (地址哈希分組)"
    msg = (
        f"⚠️ <b>疑似OHCA/OHCA懷疑</b>\n"
        f"🚨 <b>{amb_count} 台救護車前往同一地址</b>\n\n"
        f"🏙️ <b>縣市:</b> {TELEGRAM_BOTS[city_code]['city']}\n"
        f"📍 <b>地址:</b> {addr}\n"
        f"⏰ <b>時間:</b> {', '.join(t for t in times if t)}\n"
        f"🚑 <b>車輂:</b> {'; '.join(c for c in car_list if c)}\n"
        f"🌐 <b>座標:</b> {coord_str}\n"
        + (f"📊 <b>資料來源:</b> IPS 119 即時派遣 (單位數: {num_amb} 隊)\n"
           if has_ips else f"📊 <b>資料來源:</b> TPE 119 API (車數: {num_amb} 輆)\n")
    )
    # Route OHCA alerts to dedicated group if configured (traffic separation)
    chat_id = target_group or GROUP_ID_OHCA or GROUP_ID
    payload = {
        "chat_id": chat_id, "text": msg, "parse_mode": "HTML"
    }
    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            timeout=10, data=payload
        )
        r = resp.json()
        mid = r.get("result", {}).get("message_id", "?")
        print(f"  [OHCA] {addr} ({amb_count} cars, {src}) → msg_id={mid}", flush=True)
    except Exception as e:
        print(f"  [ERR]  OHCA push failed: {e}", flush=True)


def process_case(case, city_code):
    """Process a single case from the API: TWD coords → WGS84 → geocode → push."""
    # Deduplicate by case ID
    # Deduplicate by composite key (no caseId field in API response)
    case_id = f"{case.get('inTime','')}_{round(case.get('csX',0),4)}_{round(case.get('csY',0),4)}"
    if case_id and case_id in _pushed_cases:
        return
    if case_id:
        _pushed_cases.add(case_id)

    # Get TWD coordinates from API response
    cs_x = case.get("csX") or case.get("x")
    cs_y = case.get("csY") or case.get("y")
    if not cs_x or not cs_y:
        print(f"  [SKIP] No coordinates in case", flush=True)
        return

    # Convert TWD → WGS84
    if HAS_TWD:
        lat, lng = twd_to_wgs84(float(cs_x), float(cs_y))
    else:
        print(f"  [FAIL] pyproj not available for TWD conversion", flush=True)
        return

    # Reverse-geocode to get full address with 號
    if not HAS_GEOCODING:
        print(f"  [FAIL] geocoding module not available", flush=True)
        return

    geo = reverse_geocode(lat, lng)
    if not geo["success"]:
        print(f"  [FAIL] reverse-geocode failed for ({lat}, {lng})", flush=True)
        return

    addr = geo["formatted_address"]
    has_no = geo.get("has_building_no", False)
    street_num = geo.get("street_number", "")

    print(f"  [GEOCODE] ({lat:.6f}, {lng:.6f}) → {addr}"
          f"{' (' + street_num + ')' if street_num else ''}", flush=True)

    # Skip if no 號 (building number) — fuzzy address, not scene-level
    if not has_no and "號" not in addr:
        print(f"  [SKIP] {addr} — no 號, fuzzy address", flush=True)
        return

    # Push to Telegram with real case data
    push_to_telegram(city_code, addr, (lat, lng), case_data=case)


def process_coords(coords_str, city_code="01"):
    """One-shot: take a coordinates string (lat,lng), reverse-geocode, push."""
    if "," not in coords_str:
        print(f"[!] Format: lat,lng (e.g. 25.038779,121.512820)", flush=True)
        return
    lat_s, lng_s = coords_str.split(",")
    coords = (float(lat_s.strip()), float(lng_s.strip()))

    if not HAS_GEOCODING:
        print("[!] geocoding module not available", flush=True)
        return

    geo = reverse_geocode(coords[0], coords[1])
    if not geo["success"]:
        print(f"  [FAIL] reverse-geocode failed for {coords}", flush=True)
        return

    addr = geo["formatted_address"]
    has_no = geo.get("has_building_no", False)
    street_num = geo.get("street_number", "")
    print(f"  [GEOCODE] {coords} → {addr}"
          f"{' (' + street_num + ')' if street_num else ''}", flush=True)

    if not has_no and "號" not in addr:
        print(f"  [SKIP] {addr} — no 號, fuzzy address", flush=True)
        return

    push_to_telegram(city_code, addr, coords)


_ips_dispatch_cache = {}  # address → case dict cache for IPS dispatch
_ips_cache_time = 0

def fetch_ips_dispatch_with_cache():
    """Fetch IPS dispatch cases with 30s cache to avoid repeated re-login."""
    global _ips_cache_time
    now = time.time()
    if _ips_cache_time and (now - _ips_cache_time) < IPS_CACHE_TTL:
        return _ips_dispatch_cache.get("cases", [])
    # Re-fetch
    try:
        sys.path.insert(0, BASE_DIR)
        import ips_dispatch_handler
        cases = ips_dispatch_handler.fetch_ips_dispatch()
        _ips_dispatch_cache["cases"] = cases
        _ips_cache_time = now
        return cases
    except Exception as e:
        print(f"  [ERR] IPS dispatch handler error: {e}", flush=True)
        return []


_ips_geocache = {}  # address → (lat, lng) cache for IPS addresses


def fetch_dispatch_cases(city_code="01"):
    """Fetch real-time dispatch cases from the public caseList endpoint.
    
    Endpoint: POST service119.119.gov.taipei/service119/citizenCase/caseList
    No authentication required (token=anything works). Returns real-time
    emergency dispatch records with TWD97 coordinates and exact addresses.
    
    Only cases with caseStatus "到達現場" (arrived at scene) are returned.
    Coordinates: exact (csX/csY) when fuzzyAble=N, fuzzed (fuzzyX/fuzzyY) when Y.
    """
    global _dispatch_cache_time
    now = time.time()
    if _dispatch_cache_time and (now - _dispatch_cache_time) < DISPATCH_CACHE_TTL:
        return _dispatch_cache.get("cases", [])
    
    try:
        r = requests.post(
            DISPATCH_CASELIST_URL,
            data={"token": "anyone"},
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=15,
        )
        if r.status_code != 200:
            print(f"[-] Dispatch fetch failed: HTTP {r.status_code}", flush=True)
            return []
        
        data = r.json()
        rows = data.get("rows", [])
        
        cases = []
        for row in rows:
            case_status = row.get("caseStatus", "")
            if case_status != "到達現場":
                continue
            
            case_sn = row.get("sn", "")
            case_id = f"dispatch_{case_sn}"
            if case_id in _pushed_cases:
                continue
            _pushed_cases.add(case_id)
            
            # Coordinates: prefer exact (fuzzyAble=N), fallback to fuzzed
            fuzzy_able = row.get("fuzzyAble", "Y")
            if fuzzy_able == "N":
                cs_x = float(row.get("csX", 0) or 0)
                cs_y = float(row.get("csY", 0) or 0)
                address = row.get("csPlace", row.get("csPlaceFuzzy", ""))
            else:
                cs_x = float(row.get("fuzzyX", 0) or 0)
                cs_y = float(row.get("fuzzyY", 0) or 0)
                address = row.get("csPlaceFuzzy", "")
            
            case = {
                "inTime": row.get("inTime", ""),
                "csPlace": address,
                "csX": cs_x,
                "csY": cs_y,
                "csKindName": row.get("csKindName", ""),
                "caseStatus": case_status,
                "dispCarList": row.get("dpKdid", "A"),
                "numberOfAmbulance": 1,
                "dispatch_sn": case_sn,
                "csCodeName": "",
                "caseNo": case_sn,
            }
            cases.append(case)
        
        _dispatch_cache["cases"] = cases
        _dispatch_cache_time = now
        print(f"[+] Dispatch: {len(cases)} scene cases (out of {len(rows)} rows)", flush=True)
        return cases
    except Exception as e:
        print(f"[-] Dispatch fetch error: {e}", flush=True)
        return []


def ips_dispatch_to_case(ips_case, city_code):
    """Convert an IPS dispatch case dict to a service119-compatible case dict.

    Forward-geocodes the address → WGS84 → TWD97 for addr_key compatibility.
    Maps '處理中' → '到達現場' (in-progress = units on scene).
    """
    case_id = f"ips_{ips_case.get('case_no', '')}"
    if case_id in _pushed_cases:
        return None
    _pushed_cases.add(case_id)

    address = ips_case.get("address", "")
    if not address:
        return None

    # Skip fuzzy addresses (no 號 = building number)
    if "號" not in address:
        return None

    num_units = ips_case.get("num_units", 0)  # moved before geocoding for error msg
    status_text = ips_case.get("status", "")

    if not HAS_GEOCODING:
        print(f"  [FAIL] geocoding module not available for IPS", flush=True)
        return None

    # Forward geocode with caching
    if address in _ips_geocache:
        lat, lng = _ips_geocache[address]
    else:
        geo = forward_geocode(address)
        if not geo["success"]:
            # Geocoding failed — use address hash for coord-based addr_key
            # OHCA detection via numberOfAmbulance still works (push_ohca_alert handles 0 coords)
            print(f"  [IPS] {address} — geocoding failed, using address-hash key ({num_units} units)", flush=True)
            if HAS_TWD:
                cs_x, cs_y = wgs_to_twd97(0, 0)  # placeholder — addr_key will use hash fallback
            else:
                cs_x, cs_y = 0.0, 0.0
            # Fall through to return case dict without coordinates
            lat, lng = None, None
        else:
            lat, lng = geo.get("lat"), geo.get("lng")
            if not lat or not lng:
                print(f"  [FAIL] No coordinates for IPS address {address}", flush=True)
                return None
        if lat is not None:
            _ips_geocache[address] = (lat, lng)

    # Convert WGS84 → TWD97 for addr_key compatibility with service119 dispatch cases
    if lat is not None and HAS_TWD:
        cs_x, cs_y = wgs_to_twd97(lat, lng)
    elif lat is None:
        cs_x, cs_y = 0.0, 0.0  # will trigger addr_key hash fallback
    elif lat and lng:
        cs_x, cs_y = lng * 100000, lat * 100000  # HAS_TWD not available, use raw
    else:
        cs_x, cs_y = 0.0, 0.0  # fallback

    # Map status: 處理中 (in progress) → 到達現場 (arrived at scene)
    # For OHCA pipeline, "in progress" = units are on scene
    status = "到達現場" if "處理中" in ips_case.get("status", "") else ips_case.get("status", "")

    # Build unit string: e.g. "第一大隊-華山分隊、忠孝分隊、雙園分隊、龍山分隊"
    units = ips_case.get("units", [])
    if units:
        # Use first unit's prefix and append all suffixes
        parts = []
        prefix = ""
        for u in units:
            if "-" in u:
                p, s = u.split("-", 1)
                prefix = p
                parts.append(s)
            else:
                parts.append(u)
        join_str = "、".join(parts)
        disp_str = f"{prefix}-{join_str}" if prefix else join_str
    else:
        disp_str = ""

    if lat is not None:
        print(f"  [IPS] {address} → ({lat:.6f}, {lng:.6f}) — {num_units} units", flush=True)

    return {
        "inTime": ips_case.get("last_modified", ""),
        "csPlace": address,
        "csX": cs_x,
        "csY": cs_y,
        "caseStatus": status,
        "dispCarList": disp_str,
        "numberOfAmbulance": num_units,  # dispatched unit count
        "ips_case_no": ips_case.get("case_no", ""),
    }


def daemon_loop(interval=60, city_code="01"):
    """Main daemon: keep login alive, poll API for new cases, push."""
    global _running
    print(f"\n🛡️ Broadcast Daemon starting "
          f"(interval={interval}s, city={city_code})", flush=True)

    # Start login daemon for auto token renewal
    start_login_daemon()
    t = threading.Thread(target=monitor_login_daemon, daemon=True)
    t.start()

    # Restore persisted dedup state (survives daemon restart)
    load_pushed_cases()
    if _pushed_cases:
        print(f"[+] Restored {len(_pushed_cases)} pushed case IDs + "
              f"{len(_ohca_addr_keys)} OHCA addresses from cache", flush=True)

    print(f"[*] Polling citizenCase/search every {interval}s...", flush=True)

    while _running:
        try:
            token, jsession = get_valid_token()
            if token:
                print(f"[+] Token valid: {token[:25]}...", flush=True)
            else:
                print(f"[!] Token unavailable — login.py will auto-renew", flush=True)

            cases = fetch_tpe119_cases(city_code)
            # Also fetch IPS dispatch cases (real-time unit dispatch)
            if city_code == "01":
                ips_cases = fetch_ips_dispatch_with_cache()
                for ips_case in ips_cases:
                    ips_dict = ips_dispatch_to_case(ips_case, city_code)
                    if ips_dict:
                        cases.append(ips_dict)
            # Also fetch dispatch cases from public caseList endpoint
            if city_code == "01":
                dispatch_cases = fetch_dispatch_cases(city_code)
                for dc in dispatch_cases:
                    cases.append(dc)
            # Only push cases that have arrived at scene ("到現場")
            scene_cases = [c for c in cases if "到達現場" in (c.get("caseStatus", "") or "")]
            if scene_cases:
                # Sort oldest-first for clean chronological broadcast order
                scene_cases.sort(key=lambda c: c.get("inTime", ""))
                # Group by address for OHCA detection
                by_addr = {}
                for case in scene_cases:
                    case_id = f"{case.get('inTime','')}_{round(case.get('csX',0),4)}_{round(case.get('csY',0),4)}"
                    if case_id and case_id in _pushed_cases:
                        continue
                    addr_key = _case_addr_key(case)
                    by_addr.setdefault(addr_key, []).append(case)
                for addr_key, case_list in by_addr.items():
                    # OHCA guard: if this address already had OHCA alert,
                    # skip all OHCA paths — prevents repeat OHCA push
                    if addr_key in _ohca_addr_keys:
                        first = case_list[0]
                        fcid = f"{first.get('inTime','')}_{round(first.get('csX',0),4)}_{round(first.get('csY',0),4)}"
                        if fcid not in _pushed_cases:
                            process_case(first, city_code)
                            _pushed_cases.add(fcid)
                        continue
                    if len(case_list) >= 2:
                        # OHCA: two+ ambulances at same address in this cycle
                        for c in case_list:
                            cid = f"{c.get('inTime','')}_{round(c.get('csX',0),4)}_{round(c.get('csY',0),4)}"
                            _pushed_cases.add(cid)
                        _ohca_addr_keys.add(addr_key)  # mark address as OHCA'd
                        push_ohca_alert(city_code, case_list, target_group=GROUP_ID_OHCA)
                    else:
                        case = case_list[0]
                        cid = f"{case.get('inTime','')}_{round(case.get('csX',0),4)}_{round(case.get('csY',0),4)}"
                        # OHCA: any single case with numberOfAmbulance >= 2
                        num_amb = case.get("numberOfAmbulance", 0)
                        if num_amb >= 2:
                            _ohca_addr_keys.add(addr_key)  # mark address as OHCA'd
                            push_ohca_alert(city_code, [case], num_amb=num_amb, target_group=GROUP_ID_OHCA)
                            _pushed_cases.add(cid)
                            continue
                        # Cross-cycle OHCA: was a scene at this address in the last 90s?
                        if addr_key in _recent_scenes:
                            old_case = _recent_scenes[addr_key]
                            # Skip if address already had OHCA — prevents cross-cycle repeat
                            if addr_key in _ohca_addr_keys:
                                _pushed_cases.add(cid)
                                continue
                            # Compare case numbers — same case across cycles = NOT OHCA
                            old_no = old_case.get("ips_case_no") or old_case.get("dispatch_sn") or old_case.get("caseNo", "")
                            new_no = case.get("ips_case_no") or case.get("dispatch_sn") or case.get("caseNo", "")
                            if old_no and new_no and old_no != new_no:
                                # Different case numbers at same address = different dispatches = OHCA
                                _ohca_addr_keys.add(addr_key)  # mark address as OHCA'd
                                push_ohca_alert(city_code, [old_case, case], target_group=GROUP_ID_OHCA)
                            _pushed_cases.add(cid)
                            continue  # Skip regular push after cross-cycle check
                        process_case(case, city_code)
                        _pushed_cases.add(cid)
                # Update recent scene tracking + prune old entries
                now = time.time()
                for case in scene_cases:
                    ak = _case_addr_key(case)
                    _recent_scenes[ak] = case
                for ak in list(_recent_scenes.keys()):
                    if ak not in by_addr:  # address not seen in this cycle — expire it
                        del _recent_scenes[ak]
                new_count = len(by_addr)
                if new_count > 0:
                    print(f"[+] {len(scene_cases)} scene cases, {new_count} addresses processed", flush=True)
            else:
                print(f"[*] No cases or API error", flush=True)
        except Exception as e:
            print(f"[-] Daemon error: {e}", flush=True)

        # Persist dedup state (survives daemon restart / SIGKILL)
        save_pushed_cases()
        time.sleep(interval)

    # Cleanup
    if _login_process:
        _login_process.terminate()
        print("[*] login.py daemon stopped", flush=True)
    # Remove stale lock on graceful exit (SIGTERM)
    try:
        os.remove(LOCK_FILE)
    except FileNotFoundError:
        pass
    print("[*] Broadcast Daemon stopped", flush=True)


def _sigint_handler(signum, frame):
    global _running
    _running = False


def bind_telegram_group(bot_token):
    """Use Telegram getUpdates API to discover the group chat ID where the bot was added.
    
    The bot must first be added to the target group, then send a message (or the bot
    will be promoted). This auto-discovers the group ID without manual configuration.
    
    Returns the group chat ID (string) or None if not found.
    """
    try:
        url = f"https://api.telegram.org/bot{bot_token}/getUpdates"
        r = requests.get(url, timeout=10)
        data = r.json()
        if not data.get("ok"):
            return None
        for update in data.get("result", []):
            # Check my_chat_member events (bot added to group)
            chat = update.get("my_chat_member", {}).get("chat", {})
            if chat.get("type") in ("group", "supergroup"):
                return str(chat.get("id"))
            # Check message events (someone messaged the bot in a group)
            chat = update.get("message", {}).get("chat", {})
            if chat.get("type") in ("group", "supergroup"):
                return str(chat.get("id"))
        return None
    except Exception as e:
        print(f"[!] Auto-bind group ID failed: {e}", flush=True)
        return None


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TOCP Broadcast Auto-Daemon")
    parser.add_argument("--coords", help="One-shot: coordinates to push (lat,lng)")
    parser.add_argument("--interval", type=int, default=60,
                        help="Polling interval seconds (default: 60)")
    parser.add_argument("--city", default="01", choices=list(TELEGRAM_BOTS.keys()),
                        help="City code: 01=Taipei, 05=Taoyuan, 11=Kaohsiung")
    parser.add_argument("--daemon", action="store_true",
                        help="Run as background daemon")
    # One-click: bot token + auto-bind group ID
    parser.add_argument("--tg-bot-token",
                        help="One-click: Telegram bot token (auto-binds group via getUpdates)")
    parser.add_argument("--group-id",
                        help="Explicit group ID (auto-discovered from getUpdates if omitted)")
    parser.add_argument("--ohca-group-id",
                        help="OHCA alerts → this group (traffic routing)")
    parser.add_argument("--dispatch-group-id",
                        help="Regular dispatches → this group (traffic routing)")
    args = parser.parse_args()

    signal.signal(signal.SIGTERM, _sigint_handler)
    signal.signal(signal.SIGINT, _sigint_handler)

    # File-based lock: prevent multiple daemon instances (process sync)
    import atexit
    _lock_file = "/tmp/broadcast_daemon.lock"
    _lock_fd = None
    try:
        _lock_fd = os.open(_lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(_lock_fd, str(os.getpid()).encode())
        os.close(_lock_fd)
    except FileExistsError:
        print("[!] Another daemon instance is already running — kill it first or remove", flush=True)
        print(f"    lock file: {_lock_file}", flush=True)
        sys.exit(1)

    def _cleanup_lock():
        try:
            os.unlink(_lock_file)
        except OSError:
            pass
    atexit.register(_cleanup_lock)
    if args.tg_bot_token:
        TELEGRAM_BOTS[args.city]["token"] = args.tg_bot_token
        if args.group_id:
            GROUP_ID = args.group_id
        else:
            bound = bind_telegram_group(args.tg_bot_token)
            if bound:
                GROUP_ID = bound
                print(f"[+] Auto-bound group ID: {bound}", flush=True)
            else:
                print("[!] Could not auto-bind — add bot to target group first", flush=True)

    if args.ohca_group_id:
        GROUP_ID_OHCA = args.ohca_group_id

    if args.dispatch_group_id:
        GROUP_ID_DISPATCH = args.dispatch_group_id

    if args.coords:
        process_coords(args.coords, args.city)
    else:
        daemon_loop(interval=args.interval, city_code=args.city)
